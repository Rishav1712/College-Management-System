package com.college.management.controller;

import com.college.management.model.Course;
import com.college.management.service.CourseService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    // ADMIN: create course
    @PostMapping
    public Course createCourse(@RequestBody Course course) {
        return courseService.createCourse(course);
    }

    // ADMIN + STUDENT: view all
    @GetMapping
    public List<Course> getCourses() {
        return courseService.getAllCourses();
    }
}
