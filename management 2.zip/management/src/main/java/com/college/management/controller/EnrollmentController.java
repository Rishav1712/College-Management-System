package com.college.management.controller;

import com.college.management.model.Enrollment;
import com.college.management.service.EnrollmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    public EnrollmentController(EnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }

    // STUDENT or ADMIN can enroll
    @PostMapping
    public Enrollment enroll(@RequestParam Long studentId, @RequestParam Long courseId) {
        return enrollmentService.enroll(studentId, courseId);
    }

    // STUDENT or ADMIN
    @GetMapping("/student/{id}")
    public List<Enrollment> getByStudent(@PathVariable Long id) {
        return enrollmentService.getEnrollmentsByStudent(id);
    }

    // ADMIN only
    @GetMapping("/course/{id}")
    public List<Enrollment> getByCourse(@PathVariable Long id) {
        return enrollmentService.getEnrollmentsByCourse(id);
    }
}
