package com.college.management.service;

import com.college.management.dto.StudentDashboardResponse;
import org.springframework.stereotype.Service;

@Service
public class AiService {

    private final DashboardService dashboardService;

    public AiService(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    /**
     * Later: call Gemini here using dashboard data.
     * For now: just return the existing summary.
     */
    public String getSmartDashboardSummary(Long studentId) {
        StudentDashboardResponse dashboard = dashboardService.getStudentDashboard(studentId);

        // SIMPLE VERSION (no Gemini yet)
        String base = dashboard.getSummary();

        // You can enrich a bit using backend logic
        String extra = "";

        if (dashboard.getAveragePercentage() != null) {
            double avg = dashboard.getAveragePercentage();
            if (avg >= 80) {
                extra += " Overall performance is strong. Keep maintaining this consistency. ";
            } else if (avg >= 60) {
                extra += " Performance is decent, but there is room to improve in some courses. ";
            } else {
                extra += " Current performance is below average. Focusing on weak subjects could help. ";
            }
        }

        if (dashboard.getTotalFeesPending() != null && dashboard.getTotalFeesPending() > 0) {
            extra += "There are pending fees that should be cleared soon.";
        } else {
            extra += "There are no pending fees at the moment.";
        }

        return base + " " + extra;
    }
}
