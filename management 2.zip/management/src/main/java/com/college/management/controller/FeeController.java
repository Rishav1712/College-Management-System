package com.college.management.controller;

import com.college.management.model.Fee;
import com.college.management.service.FeeService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/fees")
public class FeeController {

    private final FeeService feeService;

    public FeeController(FeeService feeService) {
        this.feeService = feeService;
    }

    // ADMIN: create fee for a student
    @PostMapping
    public Fee createFee(@RequestParam Long studentId,
                         @RequestParam Double amount,
                         @RequestParam String dueDate,   // format: YYYY-MM-DD
                         @RequestParam(required = false) String remarks) {
        LocalDate due = LocalDate.parse(dueDate);
        return feeService.createFee(studentId, amount, due, remarks);
    }

    // ADMIN: mark a fee as paid
    @PostMapping("/{feeId}/pay")
    public Fee payFee(@PathVariable Long feeId,
                      @RequestParam String paymentMode) {
        return feeService.markAsPaid(feeId, paymentMode);
    }

    // ADMIN + STUDENT: get all fees for a student
    @GetMapping("/student/{id}")
    public List<Fee> getStudentFees(@PathVariable Long id) {
        return feeService.getFeesForStudent(id);
    }

    // ADMIN only: get all fees
    @GetMapping
    public List<Fee> getAllFees() {
        return feeService.getAllFees();
    }
}
