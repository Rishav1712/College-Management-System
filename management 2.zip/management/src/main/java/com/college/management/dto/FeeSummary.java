package com.college.management.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeeSummary {

    private Long feeId;
    private Double amount;
    private String status;      // PENDING / PAID / PARTIAL
    private LocalDate dueDate;
    private LocalDate paidDate;
    private String paymentMode;
    private String remarks;
}
