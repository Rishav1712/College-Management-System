package com.college.management.controller;

import com.college.management.dto.StudentDashboardResponse;
import com.college.management.service.DashboardService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/student/{id}")
    public StudentDashboardResponse getStudentDashboard(@PathVariable Long id) {
        return dashboardService.getStudentDashboard(id);
    }
}
