package com.college.management.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "fees")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // fee assigned to a student
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    private Double amount;
    private String status;      // e.g. PENDING, PAID, PARTIAL
    private LocalDate dueDate;
    private LocalDate paidDate;
    private String paymentMode; // e.g. CASH, CARD, UPI
    private String remarks;
}
