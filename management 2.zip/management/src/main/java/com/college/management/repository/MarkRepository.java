package com.college.management.repository;

import com.college.management.model.Mark;
import com.college.management.model.Student;
import com.college.management.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MarkRepository extends JpaRepository<Mark, Long> {

    List<Mark> findByStudent(Student student);
    List<Mark> findByCourse(Course course);

    boolean existsByStudentAndCourse(Student student, Course course);
}
