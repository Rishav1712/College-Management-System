package com.college.management.dto;

import com.college.management.model.enums.Role;
import lombok.Data;

@Data
public class RegisterRequest {
    private String email;
    private String password;
    private Role role;   // ADMIN or STUDENT
}
