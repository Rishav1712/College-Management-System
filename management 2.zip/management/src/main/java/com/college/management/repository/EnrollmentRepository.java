package com.college.management.repository;

import com.college.management.model.Enrollment;
import com.college.management.model.Student;
import com.college.management.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    List<Enrollment> findByStudent(Student student);
    List<Enrollment> findByCourse(Course course);
    boolean existsByStudentAndCourse(Student student, Course course);
}
