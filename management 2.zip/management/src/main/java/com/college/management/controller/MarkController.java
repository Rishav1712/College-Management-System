package com.college.management.controller;

import com.college.management.model.Mark;
import com.college.management.service.MarkService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marks")
public class MarkController {

    private final MarkService markService;

    public MarkController(MarkService markService) {
        this.markService = markService;
    }

    // ADMIN: upload or update marks
    @PostMapping
    public Mark uploadMark(@RequestParam Long studentId,
                           @RequestParam Long courseId,
                           @RequestParam Integer marks,
                           @RequestParam Integer total) {
        return markService.uploadMark(studentId, courseId, marks, total);
    }

    // STUDENT or ADMIN
    @GetMapping("/student/{id}")
    public List<Mark> getMarksForStudent(@PathVariable Long id) {
        return markService.getMarksByStudent(id);
    }

    // ADMIN only
    @GetMapping("/course/{id}")
    public List<Mark> getMarksForCourse(@PathVariable Long id) {
        return markService.getMarksByCourse(id);
    }
}
