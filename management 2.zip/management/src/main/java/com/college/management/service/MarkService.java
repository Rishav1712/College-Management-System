package com.college.management.service;

import com.college.management.model.Course;
import com.college.management.model.Mark;
import com.college.management.model.Student;
import com.college.management.repository.CourseRepository;
import com.college.management.repository.MarkRepository;
import com.college.management.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MarkService {

    private final MarkRepository markRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public MarkService(MarkRepository markRepository,
                       StudentRepository studentRepository,
                       CourseRepository courseRepository) {
        this.markRepository = markRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
    }

    public Mark uploadMark(Long studentId, Long courseId, Integer marks, Integer total) {

        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        String grade = calculateGrade(marks, total);

        Mark mark;

        // update if already exists
        if (markRepository.existsByStudentAndCourse(student, course)) {
            mark = markRepository.findByStudent(student).stream()
                    .filter(m -> m.getCourse().getId().equals(courseId))
                    .findFirst().orElseThrow();
            mark.setMarksObtained(marks);
            mark.setTotalMarks(total);
            mark.setGrade(grade);
        } else {
            mark = Mark.builder()
                    .student(student)
                    .course(course)
                    .marksObtained(marks)
                    .totalMarks(total)
                    .grade(grade)
                    .build();
        }

        return markRepository.save(mark);
    }

    public List<Mark> getMarksByStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return markRepository.findByStudent(student);
    }

    public List<Mark> getMarksByCourse(Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        return markRepository.findByCourse(course);
    }

    private String calculateGrade(int marks, int total) {
        double percent = (marks * 100.0) / total;
        if (percent >= 90) return "A+";
        if (percent >= 80) return "A";
        if (percent >= 70) return "B";
        if (percent >= 60) return "C";
        if (percent >= 50) return "D";
        return "F";
    }
}
