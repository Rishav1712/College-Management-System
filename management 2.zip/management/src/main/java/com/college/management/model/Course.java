package com.college.management.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "courses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String code;        // e.g. CS101

    @Column(nullable = false)
    private String name;        // e.g. Data Structures

    private String department;  // e.g. CSE
    private Integer credits;    // e.g. 4
    private Integer semester;   // e.g. 3
    private String description;
}
