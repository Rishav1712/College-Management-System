package com.college.management.model.enums;

public enum Role {
    ADMIN,
    STUDENT
}
