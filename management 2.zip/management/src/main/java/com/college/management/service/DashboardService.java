package com.college.management.service;

import com.college.management.dto.FeeSummary;
import com.college.management.dto.MarkSummary;
import com.college.management.dto.StudentDashboardResponse;
import com.college.management.model.Enrollment;
import com.college.management.model.Fee;
import com.college.management.model.Mark;
import com.college.management.model.Student;
import com.college.management.repository.EnrollmentRepository;
import com.college.management.repository.FeeRepository;
import com.college.management.repository.MarkRepository;
import com.college.management.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final StudentRepository studentRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final MarkRepository markRepository;
    private final FeeRepository feeRepository;

    public DashboardService(StudentRepository studentRepository,
                            EnrollmentRepository enrollmentRepository,
                            MarkRepository markRepository,
                            FeeRepository feeRepository) {
        this.studentRepository = studentRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.markRepository = markRepository;
        this.feeRepository = feeRepository;
    }

    public StudentDashboardResponse getStudentDashboard(Long studentId) {

        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        // Enrolled courses
        List<Enrollment> enrollments = enrollmentRepository.findByStudent(student);
        List<String> enrolledCourses = enrollments.stream()
                .map(e -> e.getCourse().getCode() + " - " + e.getCourse().getName())
                .collect(Collectors.toList());

        // Marks
        List<Mark> marks = markRepository.findByStudent(student);
        List<MarkSummary> markSummaries = marks.stream()
                .map(m -> MarkSummary.builder()
                        .courseCode(m.getCourse().getCode())
                        .courseName(m.getCourse().getName())
                        .marksObtained(m.getMarksObtained())
                        .totalMarks(m.getTotalMarks())
                        .grade(m.getGrade())
                        .build())
                .collect(Collectors.toList());

        Double averagePercentage = null;
        if (!marks.isEmpty()) {
            double totalPerc = marks.stream()
                    .mapToDouble(m -> m.getMarksObtained() * 100.0 / m.getTotalMarks())
                    .sum();
            averagePercentage = totalPerc / marks.size();
        }

        // Fees
        List<Fee> fees = feeRepository.findByStudent(student);
        List<FeeSummary> feeSummaries = fees.stream()
                .map(f -> FeeSummary.builder()
                        .feeId(f.getId())
                        .amount(f.getAmount())
                        .status(f.getStatus())
                        .dueDate(f.getDueDate())
                        .paidDate(f.getPaidDate())
                        .paymentMode(f.getPaymentMode())
                        .remarks(f.getRemarks())
                        .build())
                .collect(Collectors.toList());

        double totalPaid = fees.stream()
                .filter(f -> "PAID".equalsIgnoreCase(f.getStatus()))
                .mapToDouble(Fee::getAmount)
                .sum();

        double totalPending = fees.stream()
                .filter(f -> !"PAID".equalsIgnoreCase(f.getStatus()))
                .mapToDouble(Fee::getAmount)
                .sum();

        // Simple text summary (later you can call Gemini here)
        String summary = buildSummary(student.getName(), enrolledCourses.size(), averagePercentage, totalPending);

        return StudentDashboardResponse.builder()
                .studentId(student.getId())
                .name(student.getName())
                .rollNo(student.getRollNo())
                .department(student.getDepartment())
                .email(student.getEmail())
                .phone(student.getPhone())
                .enrolledCourses(enrolledCourses)
                .marks(markSummaries)
                .fees(feeSummaries)
                .averagePercentage(averagePercentage)
                .totalFeesPaid(totalPaid)
                .totalFeesPending(totalPending)
                .summary(summary)
                .build();
    }

    private String buildSummary(String name, int courseCount, Double avgPercent, double pendingFees) {
        StringBuilder sb = new StringBuilder();
        sb.append("Student ").append(name).append(" is enrolled in ")
                .append(courseCount).append(" course(s). ");

        if (avgPercent != null) {
            sb.append("Current average performance is around ")
                    .append(String.format("%.1f", avgPercent))
                    .append("%. ");
        } else {
            sb.append("Marks are not available yet. ");
        }

        if (pendingFees > 0) {
            sb.append("Pending fee amount is ₹")
                    .append(String.format("%.2f", pendingFees))
                    .append(". ");
        } else {
            sb.append("No pending fees. ");
        }

        return sb.toString();
    }
}
