package com.college.management.service;

import com.college.management.model.Fee;
import com.college.management.model.Student;
import com.college.management.repository.FeeRepository;
import com.college.management.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class FeeService {

    private final FeeRepository feeRepository;
    private final StudentRepository studentRepository;

    public FeeService(FeeRepository feeRepository,
                      StudentRepository studentRepository) {
        this.feeRepository = feeRepository;
        this.studentRepository = studentRepository;
    }

    // ADMIN: assign/create fee for a student
    public Fee createFee(Long studentId, Double amount, LocalDate dueDate, String remarks) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Fee fee = Fee.builder()
                .student(student)
                .amount(amount)
                .status("PENDING")
                .dueDate(dueDate)
                .remarks(remarks)
                .build();

        return feeRepository.save(fee);
    }

    // ADMIN: mark fee as paid
    public Fee markAsPaid(Long feeId, String paymentMode) {
        Fee fee = feeRepository.findById(feeId)
                .orElseThrow(() -> new RuntimeException("Fee record not found"));

        fee.setStatus("PAID");
        fee.setPaidDate(LocalDate.now());
        fee.setPaymentMode(paymentMode);

        return feeRepository.save(fee);
    }

    // ADMIN/STUDENT: list fees for a student
    public List<Fee> getFeesForStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        return feeRepository.findByStudent(student);
    }

    // ADMIN: list all fees
    public List<Fee> getAllFees() {
        return feeRepository.findAll();
    }
}
